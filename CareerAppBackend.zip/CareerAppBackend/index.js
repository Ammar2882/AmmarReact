const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
var path = require('path');
const app = express();
const PORT = 3000;
const { mongoUrl } = require("./keys");

require("./models/User");
require("./models/Counselor");

const requireToken = require("./middleware/requireToken");
const authRoutes = require("./routes/authRoutes");
app.use(bodyParser.json());
app.use(authRoutes);

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

mongoose.connect(mongoUrl, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true
});

mongoose.connection.on("connected", () => {
  console.log("connected to mongo");
});

mongoose.connection.on("error", (err) => {
  console.log("Error on index.js line 31 server side", err);
});

app.get("/", requireToken, (req, res) => {
  res.send({ email: req.user.email });
  res.send({ email: req.counselor.email });
});

app.listen(PORT, () => {
  console.log("server running " + PORT);
});
