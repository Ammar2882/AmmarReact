module.exports = {
    mongoUrl: "mongodb+srv://haris0014:haris0014@cluster0.r1yjt.mongodb.net/<dbname>?retryWrites=true&w=majority",
    jwtkey: "qwertyuiop",
}